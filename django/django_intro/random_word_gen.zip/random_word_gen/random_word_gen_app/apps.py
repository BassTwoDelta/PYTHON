from django.apps import AppConfig


class RandomWordGenAppConfig(AppConfig):
    name = 'random_word_gen_app'
